console.log("hello world");
// console.log(document);

var xmlhttp = new XMLHttpRequest();
console.log(xmlhttp);


